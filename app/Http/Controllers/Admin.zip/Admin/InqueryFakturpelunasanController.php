<?php

namespace App\Http\Controllers\admin;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Barang;
use App\Models\Detail_pelunasan;
use App\Models\Faktur_ekspedisi;
use App\Models\Pelanggan;
use App\Models\Faktur_pelunasan;
use App\Models\Nota_return;
use App\Models\Return_ekspedisi;
use App\Models\Satuan;
use Illuminate\Support\Facades\Validator;

class InqueryFakturpelunasanController extends Controller
{
    public function index(Request $request)
    {
        Faktur_pelunasan::where([
            ['status', 'posting']
        ])->update([
            'status_notif' => true
        ]);

        $status = $request->status;
        $tanggal_awal = $request->tanggal_awal;
        $tanggal_akhir = $request->tanggal_akhir;

        $inquery = Faktur_pelunasan::query();

        if ($status) {
            $inquery->where('status', $status);
        }

        if ($tanggal_awal && $tanggal_akhir) {
            $inquery->whereBetween('tanggal_awal', [$tanggal_awal, $tanggal_akhir]);
        } elseif ($tanggal_awal) {
            $inquery->where('tanggal_awal', '>=', $tanggal_awal);
        } elseif ($tanggal_akhir) {
            $inquery->where('tanggal_awal', '<=', $tanggal_akhir);
        } else {
            // Jika tidak ada filter tanggal hari ini
            $inquery->whereDate('tanggal_awal', Carbon::today());
        }

        $inquery->orderBy('id', 'DESC');
        $inquery = $inquery->get();

        return view('admin.inquery_fakturpelunasan.index', compact('inquery'));
    }



    public function edit($id)
    {
        $inquery = Faktur_pelunasan::where('id', $id)->first();
        $details  = Detail_pelunasan::where('faktur_pelunasan_id', $id)->get();
        $pelanggans = Pelanggan::all();
        $fakturs = Faktur_ekspedisi::where(['status_pelunasan' => null, 'status' => 'posting'])->get();
        $returns = Nota_return::all();
        return view('admin.inquery_fakturpelunasan.update', compact('details', 'inquery', 'pelanggans', 'fakturs', 'returns'));
    }

    public function update(Request $request, $id)
    {
        $validasi_pelanggan = Validator::make(
            $request->all(),
            [
                'pelanggan_id' => 'required',
                'faktur_ekspedisi_id' => 'required',
            ],
            [
                'pelanggan_id.required' => 'Pilih Pelanggan',
                'faktur_ekspedisi_id.required' => 'Pilih Faktur',
            ]
        );

        $error_pelanggans = array();

        if ($validasi_pelanggan->fails()) {
            array_push($error_pelanggans, $validasi_pelanggan->errors()->all()[0]);
        }

        $error_pesanans = array();
        $data_pembelians = collect();

        if ($request->has('faktur_ekspedisi_id')) {
            for ($i = 0; $i < count($request->faktur_ekspedisi_id); $i++) {
                $validasi_produk = Validator::make($request->all(), [
                    'faktur_ekspedisi_id.' . $i => 'required',
                    'kode_faktur.' . $i => 'required',
                    'tanggal_faktur.' . $i => 'required',
                    'total_faktur.' . $i => 'required',
                    // 'nota_return_id.' . $i => 'required',
                    // 'kode_return.' . $i => 'required',
                    // 'tanggal_return.' . $i => 'required',
                    // 'total_return.' . $i => 'required',
                    'total.' . $i => 'required',
                ]);

                if ($validasi_produk->fails()) {
                    array_push($error_pesanans, "Faktur nomor " . ($i + 1) . " belum dilengkapi!"); // Corrected the syntax for concatenation and indexing
                }

                $faktur_ekspedisi_id = is_null($request->faktur_ekspedisi_id[$i]) ? '' : $request->faktur_ekspedisi_id[$i];
                $kode_faktur = is_null($request->kode_faktur[$i]) ? '' : $request->kode_faktur[$i];
                $tanggal_faktur = is_null($request->tanggal_faktur[$i]) ? '' : $request->tanggal_faktur[$i];
                $total_faktur = is_null($request->total_faktur[$i]) ? '' : $request->total_faktur[$i];
                // $nota_return_id = is_null($request->nota_return_id[$i]) ? '' : $request->nota_return_id[$i];
                // $kode_return = is_null($request->kode_return[$i]) ? '' : $request->kode_return[$i];
                // $tanggal_return = is_null($request->tanggal_return[$i]) ? '' : $request->tanggal_return[$i];
                // $total_return = is_null($request->total_return[$i]) ? '' : $request->total_return[$i];
                $nota_return_id = empty($request->nota_return_id[$i]) ? null : $request->nota_return_id[$i];
                $kode_return = empty($request->kode_return[$i]) ? null : $request->kode_return[$i];
                $tanggal_return = empty($request->tanggal_return[$i]) ? null : $request->tanggal_return[$i];
                $total_return = empty($request->total_return[$i]) ? null : $request->total_return[$i];
                $total = is_null($request->total[$i]) ? '' : $request->total[$i];

                $total = is_null($request->total[$i]) ? '' : $request->total[$i];

                $data_pembelians->push([
                    'detail_id' => $request->detail_ids[$i] ?? null,
                    'faktur_ekspedisi_id' => $faktur_ekspedisi_id,
                    'kode_faktur' => $kode_faktur,
                    'tanggal_faktur' => $tanggal_faktur,
                    'total_faktur' => $total_faktur,
                    'nota_return_id' => $nota_return_id,
                    'kode_return' => $kode_return,
                    'tanggal_return' => $tanggal_return,
                    'total_return' => $total_return,
                    'total' => $total
                ]);
            }
        }

        if ($error_pelanggans || $error_pesanans) {
            return back()
                ->withInput()
                ->with('error_pelanggans', $error_pelanggans)
                ->with('error_pesanans', $error_pesanans)
                ->with('data_pembelians', $data_pembelians);
        }

        $tanggal1 = Carbon::now('Asia/Jakarta');
        $format_tanggal = $tanggal1->format('d F Y');

        $tanggal = Carbon::now()->format('Y-m-d');
        $cetakpdf = Faktur_pelunasan::findOrFail($id);

        // Update the main transaction
        $cetakpdf->update([
            'pelanggan_id' => $request->pelanggan_id,
            'kode_pelanggan' => $request->kode_pelanggan,
            'nama_pelanggan' => $request->nama_pelanggan,
            'alamat_pelanggan' => $request->alamat_pelanggan,
            'telp_pelanggan' => $request->telp_pelanggan,
            'keterangan' => $request->keterangan,
            // 'totalpenjualan' => str_replace('.', '', $request->totalpenjualan),
            'totalpenjualan' => str_replace(',', '.', str_replace('.', '', $request->totalpenjualan)),
            // 'dp' => str_replace('.', '', $request->dp),
            'dp' => str_replace(',', '.', str_replace('.', '', $request->dp)),
            // 'potonganselisih' => str_replace('.', '', $request->potonganselisih),
            // 'totalpembayaran' => (int)str_replace(['Rp', '.', ' '], '', $request->totalpembayaran),
            // 'selisih' => (int)str_replace(['Rp', '.', ' '], '', $request->selisih),
            // 'potongan' => $request->potongan ? str_replace('.', '', $request->potongan) : 0,
            // 'ongkos_bongkar' => $request->ongkos_bongkar ? str_replace('.', '', $request->ongkos_bongkar) : 0,
            // 'potonganselisih' => str_replace('.', '', $request->potonganselisih),
            'potonganselisih' => str_replace(',', '.', str_replace('.', '', $request->potonganselisih)),
            'totalpembayaran' => str_replace(',', '.', str_replace('.', '', $request->totalpembayaran)),
            'selisih' => str_replace(',', '.', str_replace('.', '', $request->selisih)),
            'potongan' => $request->potongan ? str_replace(',', '.', str_replace('.', '', $request->potongan)) : 0,
            'ongkos_bongkar' => $request->ongkos_bongkar ? str_replace(',', '.', str_replace('.', '', $request->ongkos_bongkar)) : 0,

            'kategori' => $request->kategori,
            'nomor' => $request->nomor,
            'tanggal_transfer' => $request->tanggal_transfer,
            // 'nominal' => str_replace('.', '', $request->nominal),
            'nominal' => str_replace(',', '.', str_replace('.', '', $request->nominal)),

        ]);

        $transaksi_id = $cetakpdf->id;
        $detailIds = $request->input('detail_ids');

        foreach ($data_pembelians as $data_pesanan) {
            $detailId = $data_pesanan['detail_id'];

            if ($detailId) {
                $detailPelunasan = Detail_pelunasan::where('id', $detailId)->update([
                    'faktur_pelunasan_id' => $cetakpdf->id,
                    // 'status' => 'posting',
                    'faktur_ekspedisi_id' => $data_pesanan['faktur_ekspedisi_id'],
                    'kode_faktur' => $data_pesanan['kode_faktur'],
                    'tanggal_faktur' => $data_pesanan['tanggal_faktur'],
                    // 'total_faktur' => str_replace('.', '', $data_pesanan['total_faktur']),
                    'total_faktur' =>  str_replace(',', '.', str_replace('.', '', $data_pesanan['total_faktur'])),
                    // 'nota_return_id' => $data_pesanan['nota_return_id'],
                    // 'kode_return' => $data_pesanan['kode_return'],
                    // 'tanggal_return' => $data_pesanan['tanggal_return'],
                    // 'total_return' => str_replace('.', '', $data_pesanan['total_return']),
                    'nota_return_id' => empty($data_pesanan['nota_return_id']) ? null : $data_pesanan['nota_return_id'],
                    'kode_return' => empty($data_pesanan['kode_return']) ? null : $data_pesanan['kode_return'],
                    'tanggal_return' => empty($data_pesanan['tanggal_return']) ? null : $data_pesanan['tanggal_return'],
                    'total_return' => empty($data_pesanan['total_return'])
                        ? null
                        : str_replace(',', '.', str_replace('.', '', $data_pesanan['total_return'])),
                    'total' => str_replace(',', '.', str_replace('.', '', $data_pesanan['total'])),
                ]);

                // Faktur_ekspedisi::where('id', $detailPelunasan->faktur_ekspedisi_id)->update(['status_pelunasan' => 'aktif']);
            } else {
                $existingDetail = Detail_pelunasan::where([
                    'faktur_pelunasan_id' => $cetakpdf->id,
                    'faktur_ekspedisi_id' => $data_pesanan['faktur_ekspedisi_id'],
                    'kode_faktur' => $data_pesanan['kode_faktur'],
                    'tanggal_faktur' => $data_pesanan['tanggal_faktur'],
                    // 'total_faktur' => str_replace('.', '', $data_pesanan['total_faktur']),
                    'total_faktur' =>  str_replace(',', '.', str_replace('.', '', $data_pesanan['total_faktur'])),
                    // 'nota_return_id' => $data_pesanan['nota_return_id'],
                    // 'kode_return' => $data_pesanan['kode_return'],
                    // 'tanggal_return' => $data_pesanan['tanggal_return'],
                    // 'total_return' => str_replace('.', '', $data_pesanan['total_return']),
                    'nota_return_id' => empty($data_pesanan['nota_return_id']) ? null : $data_pesanan['nota_return_id'],
                    'kode_return' => empty($data_pesanan['kode_return']) ? null : $data_pesanan['kode_return'],
                    'tanggal_return' => empty($data_pesanan['tanggal_return']) ? null : $data_pesanan['tanggal_return'],
                    // 'total_return' => empty($data_pesanan['total_return'])
                    //     ? null
                    //     : str_replace('.', '', $data_pesanan['total_return']),
                    // 'total' => str_replace('.', '', $data_pesanan['total']),
                    'total_return' => empty($data_pesanan['total_return'])
                        ? null
                        : str_replace(',', '.', str_replace('.', '', $data_pesanan['total_return'])),
                    'total' => str_replace(',', '.', str_replace('.', '', $data_pesanan['total'])),
                ])->first();

                if (!$existingDetail) {
                    $detailPelunasan = Detail_pelunasan::create([
                        'faktur_pelunasan_id' => $cetakpdf->id,
                        // 'status' => 'posting',
                        'faktur_ekspedisi_id' => $data_pesanan['faktur_ekspedisi_id'],
                        'kode_faktur' => $data_pesanan['kode_faktur'],
                        'tanggal_faktur' => $data_pesanan['tanggal_faktur'],
                        // 'total_faktur' => str_replace('.', '', $data_pesanan['total_faktur']),
                        'total_faktur' =>  str_replace(',', '.', str_replace('.', '', $data_pesanan['total_faktur'])),
                        // 'nota_return_id' => $data_pesanan['nota_return_id'],
                        // 'kode_return' => $data_pesanan['kode_return'],
                        // 'tanggal_return' => $data_pesanan['tanggal_return'],
                        // 'total_return' => str_replace('.', '', $data_pesanan['total_return']),
                        'nota_return_id' => empty($data_pesanan['nota_return_id']) ? null : $data_pesanan['nota_return_id'],
                        'kode_return' => empty($data_pesanan['kode_return']) ? null : $data_pesanan['kode_return'],
                        'tanggal_return' => empty($data_pesanan['tanggal_return']) ? null : $data_pesanan['tanggal_return'],
                        // 'total_return' => empty($data_pesanan['total_return'])
                        //     ? null
                        //     : str_replace('.', '', $data_pesanan['total_return']),
                        // 'total' => str_replace('.', '', $data_pesanan['total']),
                        'total_return' => empty($data_pesanan['total_return'])
                            ? null
                            : str_replace(',', '.', str_replace('.', '', $data_pesanan['total_return'])),
                        'total' => str_replace(',', '.', str_replace('.', '', $data_pesanan['total'])),
                    ]);

                    Faktur_ekspedisi::where('id', $detailPelunasan->faktur_ekspedisi_id)->update(['status_pelunasan' => 'aktif']);
                }
            }
        }
        $details = Detail_pelunasan::where('faktur_pelunasan_id', $cetakpdf->id)->get();

        return view('admin.inquery_fakturpelunasan.show', compact('cetakpdf', 'details'));
    }

    public function show($id)
    {
        $cetakpdf = Faktur_pelunasan::where('id', $id)->first();
        $details = Detail_pelunasan::where('faktur_pelunasan_id', $id)->get();

        return view('admin.inquery_fakturpelunasan.show', compact('cetakpdf', 'details'));
    }

    public function unpostpelunasan($id)
    {
        // Menggunakan find untuk mendapatkan Faktur_pelunasan berdasarkan ID
        $item = Faktur_pelunasan::find($id);

        // Memeriksa apakah Faktur_pelunasan ditemukan
        if (!$item) {
            return back()->with('error', 'Faktur pelunasan tidak ditemukan');
        }

        // Mendapatkan detail pelunasan terkait
        $detailpelunasan = Detail_pelunasan::where('faktur_pelunasan_id', $id)->get();

        // Melakukan loop pada setiap Detail_pelunasan dan memperbarui rekaman Faktur_ekspedisi terkait
        foreach ($detailpelunasan as $detail) {
            if ($detail->faktur_ekspedisi_id) {
                // Menggunakan find untuk mendapatkan Faktur_ekspedisi berdasarkan ID
                $fakturEkspedisi = Faktur_ekspedisi::find($detail->faktur_ekspedisi_id);

                // Memeriksa apakah Faktur_ekspedisi ditemukan
                if ($fakturEkspedisi) {
                    // Memperbarui status_pelunasan pada Faktur_ekspedisi menjadi 'aktif'
                    $fakturEkspedisi->update(['status' => 'posting', 'status_pelunasan' => null]);
                }
            }
        }

        try {
            // Memperbarui status pada Faktur_pelunasan menjadi 'unpost'
            $item->update(['status' => 'unpost']);

            // Melakukan loop pada setiap Detail_pelunasan dan memperbarui status menjadi 'unpost'
            foreach ($detailpelunasan as $detail) {
                $detail->update(['status' => 'unpost']);
            }

            return back()->with('success', 'Berhasil unposting pelunasan');
        } catch (\Exception $e) {
            // Menangani kesalahan pembaruan basis data
            return back()->with('error', 'Gagal unposting pelunasan: ' . $e->getMessage());
        }
    }


    public function postingpelunasan($id)
    {
        // Menggunakan find untuk mendapatkan Faktur_pelunasan berdasarkan ID
        $item = Faktur_pelunasan::find($id);

        // Memeriksa apakah Faktur_pelunasan ditemukan
        if (!$item) {
            return back()->with('error', 'Faktur pelunasan tidak ditemukan');
        }

        // Mendapatkan detail pelunasan terkait
        $detailpelunasan = Detail_pelunasan::where('faktur_pelunasan_id', $id)->get();

        try {
            // Melakukan loop pada setiap Detail_pelunasan dan memperbarui status menjadi 'posting'
            foreach ($detailpelunasan as $detail) {
                $detail->update(['status' => 'posting']);
            }

            // Memperbarui status pada Faktur_pelunasan menjadi 'posting'
            $item->update(['status' => 'posting']);

            return back()->with('success', 'Berhasil posting pelunasan');
        } catch (\Exception $e) {
            // Menangani kesalahan pembaruan basis data
            return back()->with('error', 'Gagal posting pelunasan: ' . $e->getMessage());
        }
    }


    public function hapuspelunasan($id)
    {
        $item = Faktur_pelunasan::where('id', $id)->first();

        if ($item) {
            $detailpelunasan = Detail_pelunasan::where('faktur_pelunasan_id', $id)->get();

            // Loop through each Detail_pelunasan and update associated Faktur_ekspedisi records
            foreach ($detailpelunasan as $detail) {
                if ($detail->faktur_ekspedisi_id) {
                    Faktur_ekspedisi::where('id', $detail->faktur_ekspedisi_id)->update(['status_pelunasan' => null]);
                }
            }
            // Delete related Detail_pelunasan instances
            Detail_pelunasan::where('faktur_pelunasan_id', $id)->delete();

            // Delete the main Faktur_pelunasan instance
            $item->delete();

            return back()->with('success', 'Berhasil menghapus Pelunasan Ekspedisi');
        } else {
            // Handle the case where the Faktur_pelunasan with the given ID is not found
            return back()->with('error', 'Pelunasan Ekspedisi tidak ditemukan');
        }
    }
}